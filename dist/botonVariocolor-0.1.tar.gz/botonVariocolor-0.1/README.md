# botonVariocolor
Puede sentirse libre de usar este componente para su disfrute personal.
Recomiendo visitar mi página personal para encontrar la documentación de este componente:
https://danielmera2912.github.io/